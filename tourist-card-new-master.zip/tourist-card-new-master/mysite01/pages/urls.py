from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^contact$', views.contact, name='contact'),
    url(r'^register$', views.reg, name='register'),
    url(r'^contactus$', views.contactus, name='contactus'),
    url(r'([^/]*)', views.index, name='index'),
]
