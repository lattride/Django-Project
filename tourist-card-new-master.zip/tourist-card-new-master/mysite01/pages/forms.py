from django import forms

class ContactForm(forms.Form):
   subject = forms.CharField(max_length=100,label='Name')
   email = forms.CharField(required=False,label='Your Card Number')
   message = forms.CharField(max_length=100,label='Card Expiry (mm/yy)')
   CVV = forms.CharField(max_length=100, label='CVV Number(e.g 493)')




class RegForm(forms.Form):
   subject = forms.CharField(max_length=100,label='Name')
   dob = forms.DateField(required=False,label='Date Of Birth')
   email = forms.CharField(label='Email Address')
   message = forms.CharField(label='Create Password')
   address1 = forms.CharField(max_length=100, label='Address Line 1')
   address2 = forms.CharField(max_length=100, label='Address Line 2')
   address3 = forms.CharField(max_length=100, label='County')


class ContactusForm(forms.Form):
   subject = forms.CharField(max_length=100,label='Name')
   email = forms.CharField(required=False,label='Your Email Address')
   message = forms.CharField(widget=forms.Textarea, label='Your Message')
